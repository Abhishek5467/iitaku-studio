Original static modular prop. Dimensions are metres. GLB includes vertex colours; OBJ is geometry only. No rig or animation.
